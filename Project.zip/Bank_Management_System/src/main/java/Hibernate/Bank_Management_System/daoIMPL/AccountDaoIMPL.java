package Hibernate.Bank_Management_System.daoIMPL;


import java.util.*;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Hibernate.Bank_Management_System.dao.AccountDao;

import Hibernate.Bank_Management_System.entity.Account;

public class AccountDaoIMPL implements AccountDao {
	
    private SessionFactory sessionFactory;
    private AccountDao accountDao;
    //Validation
    private Validator validator;

    // Constructor to inject SessionFactory
    public AccountDaoIMPL(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }

    // For adding and saving account
    @Override
    public void save(Account account) {
    	//To Validate customer
        Set<ConstraintViolation<Account>> violations = validator.validate(account);
        if (!violations.isEmpty()) {
            for (ConstraintViolation<Account> violation : violations) {
                System.out.println(violation.getMessage());
            }
            return;
        }
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        session.save(account); // Save account to the database

        transaction.commit(); // Commit the transaction
        System.out.println("Account added successfully!");
    }

    //To get account by customer id
    @Override
    public Account findById(Long acc_id) {
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        Account account = session.get(Account.class, acc_id); // To get account by ID

        transaction.commit();
        return account;
    }

    // To get all accounts
    @Override
    public List<Account> getAllAccounts() {
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        Query<Account> query = session.createQuery("from Account", Account.class); // To display all accounts
        List<Account> accounts = query.getResultList();

        transaction.commit();
        return accounts;
    }
}
