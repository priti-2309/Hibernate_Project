package Hibernate.Bank_Management_System.daoIMPL;

import javax.validation.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Hibernate.Bank_Management_System.dao.EmployeeDao;
import Hibernate.Bank_Management_System.entity.Employee;
import Hibernate.Bank_Management_System.util.HibernateUtil;

import java.util.List;
import java.util.Set;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class EmployeeDaoIMPL implements EmployeeDao {
	
    private SessionFactory sessionFactory;
    private EmployeeDao employeeDao;
    //Validation
    private Validator validator;

    // Constructor to inject SessionFactory
    public EmployeeDaoIMPL(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }

    // For adding and saving employee
    @Override
    public void save(Employee employee) {
    	//To Validate employee
        Set<ConstraintViolation<Employee>> violations = validator.validate(employee);
        if (!violations.isEmpty()) {
            for (ConstraintViolation<Employee> violation : violations) {
                System.out.println(violation.getMessage());
            }
            return;
        }
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        session.save(employee); //If validation is done, it saves employee data

        transaction.commit(); // Commit the transaction
        System.out.println("Employee added successfully!");
    }

    //To get employee by employee id
    @Override
    public Employee getById(int emp_id) {
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        Employee employee = session.get(Employee.class, emp_id); //To fetch employee by ID

        transaction.commit();
        return employee;
    }

    // To get all employee
    @Override
    public List<Employee> getAllEmployee() {
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        Query<Employee> query = session.createQuery("from Employee", Employee.class); // Retrieve all employee
        List<Employee> employee = query.getResultList();

        transaction.commit();
        return employee;
    }
}
