package Hibernate.Bank_Management_System.daoIMPL;

import javax.validation.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Hibernate.Bank_Management_System.dao.LoanDao;
import Hibernate.Bank_Management_System.entity.Loan;
import Hibernate.Bank_Management_System.util.HibernateUtil;

import java.util.List;
import java.util.Set;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class LoanDaoIMPL implements LoanDao {
	
    private SessionFactory sessionFactory;
    private LoanDao loanDao;
    //Validation
    private Validator validator;

    // Constructor to inject SessionFactory
    public LoanDaoIMPL(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        this.validator = factory.getValidator();
    }

    // For adding loan
    @Override
    public void saveLoan(Loan loan) {
    	//To Validate customer
        Set<ConstraintViolation<Loan>> violations = validator.validate(loan);
        if (!violations.isEmpty()) {
            for (ConstraintViolation<Loan> violation : violations) {
                System.out.println(violation.getMessage());
            }
            return;
        }
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        session.save(loan); //If the amount is valid, it is saved

        transaction.commit(); // Commit the transaction
        System.out.println("Loan added successfully!");
    }

    // To get all customers
    @Override
    public List<Loan> getAllLoan() {
        Session session = sessionFactory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        Query<Loan> query = session.createQuery("from Loan", Loan.class); // Retrieve all customers
        List<Loan> loans = query.getResultList();

        transaction.commit();
        return loans;
}
}
