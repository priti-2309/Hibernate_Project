package Hibernate.Bank_Management_System.service;

import java.util.List;

import Hibernate.Bank_Management_System.dao.CustomerDao;
import Hibernate.Bank_Management_System.dao.EmployeeDao;
import Hibernate.Bank_Management_System.daoIMPL.CustomerDaoIMPL;
import Hibernate.Bank_Management_System.entity.Customer;
import Hibernate.Bank_Management_System.entity.Employee;

import java.util.List;

public class EmployeeService {
    private EmployeeDao employeeDAO;

    // Constructor to inject DAO
    public EmployeeService(EmployeeDao employeeDAO) {
        this.employeeDAO = employeeDAO;
    }

    // Add a new employee
    public void save(Employee employee) {
        employeeDAO.save(employee);
    }

    // Get employee by ID
    public Employee getCustomer(int emp_id) {
        return employeeDAO.getById(emp_id);
    }

    // Get all employee
    public List<Employee> getAllEmployee() {
        return employeeDAO.getAllEmployee();
    }
}
