package Hibernate.Bank_Management_System.service;

import java.util.List;

import Hibernate.Bank_Management_System.dao.CustomerDao;
import Hibernate.Bank_Management_System.daoIMPL.CustomerDaoIMPL;
import Hibernate.Bank_Management_System.entity.Customer;

import java.util.List;

public class CustomerService {
    private CustomerDao customerDAO;

    // Constructor to inject DAO
    public CustomerService(CustomerDao customerDAO) {
        this.customerDAO = customerDAO;
    }

    // Add a new customer
    public void saveCustomer(Customer customer) {
        customerDAO.save(customer);
    }

    // Get customer by ID
    public Customer getCustomer(int customer_id) {
        return customerDAO.getById(customer_id);
    }

    // Get all customers
    public List<Customer> getAllCustomers() {
        return customerDAO.getAllCustomers();
    }
}
