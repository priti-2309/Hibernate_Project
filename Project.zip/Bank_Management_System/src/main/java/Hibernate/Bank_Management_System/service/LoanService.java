package Hibernate.Bank_Management_System.service;

import java.util.List;

import Hibernate.Bank_Management_System.dao.LoanDao;
import Hibernate.Bank_Management_System.entity.Loan;

import java.util.List;

public class LoanService {
    private LoanDao loanDAO;

    // Constructor to inject DAO
    public LoanService(LoanDao loanDAO) {
        this.loanDAO = loanDAO;
    }

    // Add a new loan
    public void saveLoan(Loan loan) {
        loanDAO.saveLoan(loan);
    }

    // Get all customers
    public List<Loan> getAllLoan() {
        return loanDAO.getAllLoan();
    }
}
