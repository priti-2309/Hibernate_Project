package Hibernate.Bank_Management_System.service;

import java.util.List;

import Hibernate.Bank_Management_System.dao.BranchDao;
import Hibernate.Bank_Management_System.entity.Branch;

import java.util.List;

public class BranchService {
    private BranchDao branchDAO;

    //Constructor to inject DAO
    public BranchService(BranchDao branchDAO) {
        this.branchDAO = branchDAO;
    }

    //To get all Branches
    public List<Branch> getAllBranches() {
        return branchDAO.getAllBranches();
    }
}
