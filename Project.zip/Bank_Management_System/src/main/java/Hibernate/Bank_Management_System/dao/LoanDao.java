package Hibernate.Bank_Management_System.dao;

import java.util.List;

import Hibernate.Bank_Management_System.entity.Loan;

public interface LoanDao {
    
	//To add loan details
	void saveLoan(Loan loan);
    	
	//To get all Loan details
    List<Loan> getAllLoan();
    
}