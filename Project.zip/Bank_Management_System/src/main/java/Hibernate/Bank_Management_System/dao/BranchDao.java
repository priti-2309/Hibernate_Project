package Hibernate.Bank_Management_System.dao;

import java.util.List;

import Hibernate.Bank_Management_System.entity.Branch;

public interface BranchDao {
	//To display all the existing branches of the bank
    List<Branch> getAllBranches();
    
}
